Do NOT use these graphics in any other projects!!!

PythianRealms will stop using these graphics soon, so do NOT use them in any case! They are only here to make PythianRealms *work*.