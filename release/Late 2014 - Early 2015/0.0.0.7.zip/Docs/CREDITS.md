CREDITS

I'd like to thank the following people for their contributions to PythianRealms:

- Wing from Indie Rising: Thank you for your donation.
- Brandon Fuller: Thank you for your donation.
- Numberplay from 8BitMMO: Thank you for the graphics from your texture pack at http://forums.8bitmmo.net/index.php?/topic/6486-numberpack-texture-pack-by-numberplay/ .
- SapphireCoyote from 8BitMMO: Thank you for the Light Crystal and Portal textures.

Musicians:

- LiteratureBeast - https://soundcloud.com/literature-corner: Thank you for "Running Freedom".
- Eric Matyas - http://soundimage.org: Thank you for "Medieval Halloween", "The Oppressed", "History Piano", and "Bustling Ancient City".
- Eric A Schaefer - https://soundcloud.com/easchaefer: Thank you for "Chivalry Theme".
- AlexRufire - https://soundcloud.com/alexrufire: Thank you for "Irish Dance".

Fonts:

- gameFont: This font is the Ubuntu Font by Canonical.
- magicFont: This font is the Magic School Font by FontMesa.