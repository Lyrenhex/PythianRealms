Disclaimer: None of the music in this folder were made by me and are either free to use by their respective owners or have granted express permission for me to use them. Credits for each music piece are below:

Running Freedom - LiteratureBeast on SoundCloud - https://soundcloud.com/literature-corner

Medieval Halloween - Eric Matyas - soundimage.org
Across the Moat - Eric Matyas - soundimage.org
The Oppressed - Eric Matyas - soundimage.org
History Piano - Eric Matyas - soundimage.org
Bustling Ancient City - Eric Matyas - soundimage.org

Chivalry Theme - Eric A Schaefer - https://soundcloud.com/easchaefer

Irish Dance - AlexRufire - https://soundcloud.com/alexrufire