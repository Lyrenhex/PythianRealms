1 - Short But Sweet

2 - This is BLUESHIFT.

3 - BLUESCREEN!
4 - Keyboard Demo Attack!

5 - Are You Gunna Eat That

6 - Oh I Feel Just Fine... (Because I'm Making Macaroni)

7 - Magnetic Jellyfish Dance Party

8 - Four Color Hero
9 - BSOD'd
10 - BLUENOISE
11 - There's Always Next Week
12 - Nostalgia Breaks Hearts
13 - Analogue Dream Girl
14 - Grayscale
15 - This Broken Heart Has Too Many Pieces
16 - Hello World
17 - 9am Skies
18 - Blueberry Jam
19 - Bitmap Blues
20 - Heat Death
21 - Her #0000ff Eyes
22 - Zero-G Lemonade