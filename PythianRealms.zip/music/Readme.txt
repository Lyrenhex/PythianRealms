1 - Bustling Ancient City
2 - Exploration
3 - History Piano
4 - Melodie Antique Francaise
5 - Medieval Banquet
6 - No Survivors
7 - The Town of Witchwoode