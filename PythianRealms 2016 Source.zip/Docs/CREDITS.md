CREDITS



I'd like to thank the following people for their contributions to PythianRealms:



Graphics:


- ALinkToTheFuture from 8BitMMO

- SapphireCoyote from 8BitMMO


- Vojta "Vus" Balcar: Logo.

Musicians:


- Bumchin from 8BitMMO: Short But Sweet

- PROTODOME (http://creativecommons.org/licenses/by-nc-nd/3.0/) [http://protodome.bandcamp.com/album/blueshift] BLUESHIFT album.



Fonts:


- gameFont: This font is the Ubuntu Font by Canonical.

- magicFont: This font is the Ubuntu Font by Canonical.



Support:


- Wing from Indie Rising: Donation.

- Brandon Fuller: Donation.